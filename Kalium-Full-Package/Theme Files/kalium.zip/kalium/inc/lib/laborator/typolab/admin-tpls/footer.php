<?php
/**
 *	TypoLab Footer
 *	
 *	Laborator.co
 *	www.laborator.co 
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<div class="typolab-footer">
	&copy; TypoLab &ndash; an ultimate font library developed by <a href="https://laborator.co/" target="_blank">Laborator.co</a>
</div>