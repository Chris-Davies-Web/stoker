<?php
/**
 *	About Page of Kalium Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */

?>
<div class="wrap about-wrap">
	<?php include 'about-header.php'; ?>
	<?php include 'whats-new.php'; ?>
</div>